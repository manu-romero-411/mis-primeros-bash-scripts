#!/bin/bash
juego=$(zenity --file-selection --title="Selecciona un archivo J2ME" --file-filter=*.jar)
if [[ $? != 0 ]]
then
	zenity --error --text="No se ha seleccionado ningún archivo de Java."
	exit 1
else
	echo $juego
	rutaproto="Z:$juego"
	/usr/share/playonlinux/playonlinux --run "java" -cp "Z:\home\usuario\Juegos\ROMs\J2ME\KEmulator\KEmulator.jar" emulator.Emulator -jar "$(echo "$rutaproto" | tr -s '//' '\\')" -awt -lwj
fi
exit 0