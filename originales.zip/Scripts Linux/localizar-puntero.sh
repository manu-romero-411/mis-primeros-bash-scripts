#!/bin/bash
/home/manu/Comandos/locate-pointer &
sleep 0.5
killall locate-pointer
exit 0