#!/bin/sh
echo "Introduce un número del 0 al 7. 0 es el brillo más bajo, y 7 es el más alto"
read BRILLO
echo $BRILLO > /sys/class/backlight/acpi_video0/brightness
exit 0