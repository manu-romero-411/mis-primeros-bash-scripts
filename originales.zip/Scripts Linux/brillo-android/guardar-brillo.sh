#!/system/bin/sh
if [ ! -f /system/guardar-brillo ]
then
	echo 4 > /sys/class/backlight/acpi_video0/brightness
else
	BRILLOGUARDADO=`cat /system/brillo-guardado`
	echo $BRILLOGUARDADO > /sys/class/backlight/acpi_video0/brightness
fi
exit 0
