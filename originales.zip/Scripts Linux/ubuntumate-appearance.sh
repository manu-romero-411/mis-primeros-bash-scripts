
#!/bin/bash

dconf write /org/mate/desktop/interface/gtk-theme "'Arc'"
dconf write /org/mate/desktop/interface/icon-theme "'Vivacious-Dark-Blue'"
dconf write /org/mate/marco/general/theme "'Arc'"
FONDO="$HOME/Imágenes/default-wallpaper.png"
gsettings set org.mate.background picture-filename "$FONDO"
exit 0
 
