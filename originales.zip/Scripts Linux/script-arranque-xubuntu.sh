#!/bin/bash
xrandr --output LVDS1 --set "scaling mode" Full
xbcg -b 0.02 -c 0.75 -g 1.00
/home/manu/Comandos/login-sound &
sleep 3
QUEHACER=$(cat /home/manu/Anotaciones)
notify-send --icon=xfce4-notes-plugin "Cosas que hay que hacer" "$QUEHACER"
exit 0
