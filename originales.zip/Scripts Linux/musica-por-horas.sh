#!/bin/bash
cd ~
if [[ $(date +%H) -ge 20 ]] && [[ $(date +%H) -le 23 ]]; then
	vlc Música/playlist-solo-instrumentales.m3u
else
	vlc Música/playlist.m3u
fi
exit 0
