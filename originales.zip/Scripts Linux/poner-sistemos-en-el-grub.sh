#!/bin/bash

function anadir_android(){
	clear
	while :
	do
		echo " ¿Usar la configuración de siempre (en un /dev/sda6)? "
		echo "1. Configuración de siempre"
		echo "2. En un /dev/sda7, instalar el sistemo en partición pelada."
		echo "3. Otra configuración...".
		echo -n "Seleccione una opcion [1 - 4]:"
		read opcionandroid
		case $opcionandroid in
			1) DISCO=0;
			PARTICION=6;
			CARPETA=/usuario/Android/android-x86;
			clear;
			break;;
			2) DISCO=0;
			PARTICION=7;
			CARPETA=/;
			clear;
			break;;
			3)clear;
			fdisk -l;
			echo -n "Arriba se ve un esquema básico de los discos ahora instalados en el sistema. Interesan los n primeros en función de los n discos duros del ordenador. Fíjate en la letra del final de los 'nombres' de los discos (p. ej., sda, en este caso fíjate en la a) y asígnale un número al disco duro donde quieras instalar Android (p. ej, a la a correspondería un 1, y así). Ten cuidado, ya que si metes un número erróneo, Android no arrancará. Escríbelo a continuación:" ;
			read disco;
			echo "Has escogido el disco $disco."
			DISCO=$(expr $disco - 1);
			echo -n "Ahora fíjate en el número del final de los 'nombres' de los discos (p. ej., sda1, en este caso fíjate en el 1) y escoge el número de la partición del disco duro donde quieras instalar Android (p. ej, a la a correspondería un 1, y así). Escríbelo a continuación:" ;
			read PARTICION;
			echo "Has escogido la partición $PARTICION del disco $disco."
			echo -n "Monta la partición donde se vaya a instalar Android, y ve a la ruta exacta de la instalación. Desde ahí apunta la ruta del directorio en el que estás, pero sin tener en cuenta las carpetas del sistema que no son del dispositivo (así, si quiero instalar Android en un pendrive llamado MANU-USB1, el pendrive se montará por defecto en /media/usuario/MANU-USB1. Si yo quiero instalar Android en una carpeta Sistemo dentro de ese pendrive, aquí pongo /Sistemo, y no /media/usuario/MANU-USB1/Sistemo). Apunta eso a continuación:"
			read CARPETA;
			clear;
			break;;
			*) echo "$opcionandroid no es una opcion válida.";
			echo "Presiona una tecla para continuar...";
			read foo;;
		esac
	done
	echo "Añadiendo Android al menú del arranque de Linux..."
	echo " 
menuentry "Android OS" --class android --class linux{
set root=(hd$DISCO,$PARTICION)
linux $CARPETA/kernel quiet root=/dev/ram0 androidboot.hardware=android_x86 video=-16 SRC=$CARPETA
initrd $CARPETA/initrd.img
}" >> /etc/grub.d/40_custom
	chmod 755 /etc/grub.d/40_custom
	update-grub2
	exit 0
	}
	
function anadir_windows(){
	clear
	echo "Próximamente"
	sleep 1
	clear
	update-grub2
	clear
	}
	
function anadir_isoubuntu(){
	clear
	echo "Próximamente"
	sleep 1
	clear
	update-grub2
	clear
	}
	
function menu(){
clear
while :
do
	echo " ¿Qué sistemo quieres poner en el GRUB? "
	echo "1. Android"
	echo "Windows (próximamente)"
	echo "ISO de Ubuntu (próximamente)"
	echo "4. Salir"
	echo -n "Seleccione una opcion [1 ó 4]"
	read opcion
	case $opcion in
		1) anadir_android; break;;
		2) anadir_windows; break;;
		3) anadir_isoubuntu; break;;
		4) clear
		echo "El script se cerrará... Hasta la próxima.";
		sleep 1.25;
		clear;
		exit 1;;
		*) echo "$opcion no es una opcion válida.";
		echo "Presiona una tecla para continuar...";
		read foo;;
	esac
done
}

if [[ $USER != root ]]; then
	echo "Debes ser root para poder continuar."
	exit 1
else
	if [[ $1 == android ]]; then
		anadir_android
	elif [[ $1 == windows ]]; then
		anadir_windows
	elif [[ $1 == isoubuntu ]]; then
		anadir_isoubuntu
	else
		menu
	fi
fi
